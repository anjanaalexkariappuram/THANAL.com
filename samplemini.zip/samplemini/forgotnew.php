<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="" href="index.html">
						<img src="" alt="">
                        <h3>THANAL.com</h3>
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row ml-0 w-100">
							<div class="col-lg-12 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="index.html">Home</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="login.php">Login</a>
									</li>
									
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Registration</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="nursereg.html">Home Nurse</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="">Patient</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="docreg.html">Doctor</a>
											</li>
										</ul>
									</li>
									
									<li class="nav-item">
										<a class="nav-link" href="index.html">Logout</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->

	<!--================ End Home Banner Area =================-->

	<!--================ Procedure Category Area =================-->
	
				
            <br>
            <br>
            <br>
            <br>
            
             <div class="col-md-6">
                        <div class="row contact_form_area">
                        <br>
                            <h3 class="contact_title">CHANGE PASSWORD</h3><br>
                            <form action="forgot.php" method="POST" id="login">
                                <div class="form-group col-md-12">
                                  <input type="text" class="form-control" autocomplete="off" id="uname" name="uname" placeholder="UserName*">
                                </div>
                                <div class="form-group col-md-12">
                                  <input type="password" class="form-control" autocomplete="off" id="old" name="old" placeholder="CurrentPassword*">
                                </div>
                                <div class="form-group col-md-12">
                                  <input type="password" class="form-control" autocomplete="off" id="new" name="new" placeholder="NewPassword*">
                              </div>
                                  <div class="form-group col-md-12">
                                  <input type="password" class="form-control" autocomplete="off" id="conf" name="conf" placeholder="ConfirmPassword*">
                                </div>
                               
                                
                                <div class="form-group col-md-12">
                                    <button class="btn btn-default submit_btn" type="submit" name="submit" >Submit </button>
                                 </div>
                                 

                            </form>
                           
                        </div>
                    </div>
                        
                       
                    </form>
                </div>
            
        
                
   </body>

</html>


