<?php 
include 'co.php'; 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
          <h2 align="center">Registered Home Nurse</h2>
            <br />
<form id="form1" name="myform" method="post" action="">
  <table width="700" height="128" border="1">
    <tr>
      <th width="44" scope="row">Name</th>
      <td width="34">Mobile No</td>
      <td width="44">City</td>
      <td width="55">Pin</td>
      <td width="49">House Name</td>
      <td width="46">Email</td>
      <td width="85">Gender</td>
      <td width="63">Date of Birth</td>
      <td width="49">Certificate</td>
     
    </tr>
    
    <?php
	
	$e=mysql_query("select homereg.* from homereg,login1 where login1.usertype='1'");
	if(mysql_num_rows($e)>0)
	{
		while($e1=mysql_fetch_array($e))
	{
		
	?>
    <tr>
      <th scope="row"><?php  echo $e1[1] ?></th>
      <td><?php  echo $e1[2] ?></td>
      <td><?php  echo $e1[3] ?></td>
      <td><?php  echo $e1[4] ?></td>
      <td><a href="folder/<?php  echo $e1[5] ?>"><?php  echo $e1[5] ?></a></td>
      <td><?php  echo $e1[6] ?></td>
      <td><?php  echo $e1[8] ?></td>
      <td><?php  echo $e1[11] ?></td>
      <td><?php  echo $e1[12] ?></td>
     
    </tr>
    
    <?php }} ?>
  </table>
</form>
</body>
</html>
