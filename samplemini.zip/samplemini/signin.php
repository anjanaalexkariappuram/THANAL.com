<?php 


include("co.php");
if(isset($_POST['submit']))
{
    $uname =$_POST['uname'];
	$pass =$_POST['pass'];


$sql="select * from login1 where username='$uname'";


$result=mysqli_query($co,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount!=0)
{

	while($row=mysqli_fetch_array($result))
	{
		$dbu_name=$row['username'];
		$dbu_pass=$row['password'];
		$dbu_type=$row['usertype'];

        
		if($dbu_name==$uname && $dbu_pass==$pass)
		{
			//$_SESSION['uname']=$dbu_name;
            //$_SESSION['pass']=$dbu_pass;
		     //echo $dbu_type;
			if($dbu_type==0)	
			{
				//$_SESSION['usertype']="admin";
               	header('Location: homepage.php');
			}
			else if($dbu_type==1)
			{
				//$_SESSION['usertype']="Seller";
                	header('Location: nursehome.php');
			}
			else if($dbu_type==2)
			{
				//$_SESSION['usertype']="User";
				header('Location: doctorhome.php');	
			}
			else if($dbu_type==3)
			{
				//$_SESSION['usertype']="User";
				header('Location: patienthome.php');	
			}
		}
		else
        {
				//header("location:signin.php?error=wrong password");
          //echo "wrong";
        }
	}
}
else
{
			//header("location:signin.php?error=User Not Found");
			//echo "not found";	
			header('Location: login.php');
}
}
?>

