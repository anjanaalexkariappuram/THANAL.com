<?php
include("co.php");
if(isset($_POST['submit']))
{
    $uname =$_POST['uname'];
	$pass =$_POST['pass'];


$ins=mysqli_query($co,"select * from login1 where username='$uname' and password='$pass'");
	 $m=mysqli_fetch_array($ins,MYSQLI_ASSOC);
	if($m>0)
	{
	
      $dbu_name=$m['username'];
     $dbu_pass=$m['password'];
    $type=$m['usertype'];
   $lid=$m['loginid'];
   $sq=mysqli_query($co,"select apstatus from homereg where loginid='$lid'");
   $w=mysqli_fetch_array($sq,MYSQLI_ASSOC);

        
		if($dbu_name==$uname && $dbu_pass==$pass)
		{
			//$_SESSION['uname']=$dbu_name;
            //$_SESSION['pass']=$dbu_pass;
		     //echo $dbu_type;
			if($dbu_type==0)	
			{
				
               	header('Location: homepage.php');
			}
			else if($dbu_type==1 and $w['apstatus']=='1' )
			{
				
                	"<script>
      window.location='nursehome.php'</script>";
			}
			else if($dbu_type==2)
			{
				
				header('Location: doctorhome.php');	
			}
			else if($dbu_type==3)
			{
				//$_SESSION['usertype']="User";
				header('Location: patienthome.php');	
			}
		}
		else
        {
				//header("location:signin.php?error=wrong password");
          //echo "wrong";
        }
	}
}
else
{
			//header("location:signin.php?error=User Not Found");
			//echo "not found";	
			header('Location: login.php');
}

?>

