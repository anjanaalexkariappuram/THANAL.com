<?php 
include 'co.php'; 
?>




<?php


if(isset($_POST['submit']))
{
  $a=$_POST['name'];
  $b=$_POST['phone'];
  $c=$_POST['age'];
  $d=$_POST['disease'];
  $e=$_POST['dname'];
  $f=$_POST['apdate'];
  
  
  
    
	
$sql="insert into appointment (`paname` ,`pamobno` , `paage` , `disease` , `padocname` , `padate`) values ('$a', '$b', '$c', '$d', '$e', '$f')";
if(mysqli_query($co,$sql))
      echo "<script> alert('Success');
           window.location='docappointment.html'</script>";
}

   
?>