<?php
include "co.php";
$b=$_GET['id'];
$sql=mysqli_query($co,"delete  from homereg where loginid='$b'");
$sqll=mysqli_query($co,"delete  from login1 where loginid='$b'");
if ($sql && $sqll ){
echo "<script>alert('Removed');
      windowocation='approve.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>
