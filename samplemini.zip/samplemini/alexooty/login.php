<?php
include 'co.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>studentlogin</title>
<link rel="stylesheet" href="new.css">
</head>
<body >
<div class="h1">
<h1><b><center>AJCE NSS</center></b>
</div>
<div class="box">
<h2>login</h2>
<form method="post" action="login.php">
<div class="inputBox">
<label>USERNAME</label>
<input type="text" name="username" required>
</div>
<div class="inputBox">
<label>PASSWORD</label>
<input type="text" name="password" required>

</div>
<input type="submit" name="submit" value="Submit">

<table>
 <tr>
        <td>
                 
        
               New User? <a href="sregg.php">Register</a>
        </td>
        </tr>
		</table>
</form>
</div>

</body>
</html>
<?php
if(isset($_POST["submit"]))
{


	$r=$_POST["username"];

    $s=$_POST["password"];
//    $_SESSION['r']=$r;
	
	$ins=mysqli_query($co,"select * from login where emailid='$r' and password='$s' ");
	 $m=mysqli_fetch_array($ins,MYSQL_ASSOC);
	if($m>0)
	{
	
   
    $type=$m['usertype'];
   $lid=$m['userid'];
   $sq=mysqli_query($co,"select approvedstatus from register where userid='$lid'");
   $w=mysqli_fetch_array($sq,MYSQLI_ASSOC);
    if($type=='admin')
    {
        ?>
        <script type="text/javascript">window.location="adminhome.html";</script>
        <?php

    }
   
    else if($type=='user' and $w['approvedstatus']=='1' )
    {
    	?>
<script type="text/javascript">window.location="studenthome.html";</script>
        <?php


    }
	 else if($type=='programofficer')
    {
    	?>
<script type="text/javascript">window.location="programofficerhome.html";</script>
        <?php


    }
 else if($type=='volunteersec')
    {
    	?>
<script type="text/javascript">window.location="volunteersec.html";</script>
        <?php


    }

    }
   else {
    		?>
    		<script type="text/javascript">alert("login failed");</script>
    		<?php
    	}	
   }
   ?>


