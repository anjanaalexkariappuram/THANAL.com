<?php 
include '../../miniprojectn/thanaln/co.php'; 
?>




<?php


if(isset($_POST['submit']))
{
  $a=$_POST['name'];
  $b=$_POST['age'];
  $c=$_POST['pgender'];
  $d=$_POST['city'];
  $e=$_POST['house'];
  $f=$_POST['category'];
  $j=$_POST['username'];
  $k=$_POST['pass'];
  $l=$_POST['cpass'];
 
   
     $ss=mysqli_query($co,"select * from login1 where username='$j'");
	$i=mysqli_num_rows($ss);
	if($i>0)
	{
         echo "
        <script>
        alert('already exists username');
        </script>";
		
	}
	else
	{
		//echo"hii";
 $sq="insert into login1(username,password,usertype)values('$j','$k',3)";
if(mysqli_query($co,$sq))
{
	
	$sql=mysqli_query($co,"select loginid from login1 where username='$j'");
	$re=mysqli_fetch_array($sql,MYSQLI_ASSOC);
	$lid=$re['loginid'];
	echo "<script>alert('$lid');</script>";
$sql="insert into patientreg (loginid, pname , page , pgender , pcity , phouse , pcategory ) values ('$lid', '$a', '$b', '$c', '$d', '$e', '$f' )";
if(mysqli_query($co,$sql))
      echo "<script> alert('Success');
           window.location='login.php'</script>";
}
}
   }
?>