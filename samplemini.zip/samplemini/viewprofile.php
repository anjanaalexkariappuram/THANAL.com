<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" href="img/favicon.png" type="image/png">
  <title>Hospice Medical</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
  <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
  <link rel="stylesheet" href="vendors/animate-css/animate.css">
  <link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
  <!-- main css -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
    
    
</head>

<body>



  <!--================Header Menu Area =================-->
  <header class="header_area">
    <div class="top_menu row m0">
      
        
      </div>
    </div>
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <a class="navbar-brand logo_h" href="">
            <img src="newlogo.png" alt="">
                        
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
           aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- Collect the nav links, forms, and other content for toggling -->
          
      </nav>
    </div>
  </header>
  <br><br><br><br><br><br><br><br><br><br>
  <?php
session_start();
$login=$_SESSION['login'];
$usr_name=$_SESSION['nuname'];
$lid=$_SESSION['loginid'];
if($login)
{
	?>
<?php
include 'co.php';

$q1="select * from homereg where loginid='$lid'";
$sql=mysqli_query($co,$q1);
?>

<table width="1236" border="0" cellpadding="0" cellspacing="0">
 
  <tr>
    <td width="459" height="700"></td>
    <td width="366" valign="top"><div align="center">
      <p>Edit your profile </p>
      
      <form name="form1" method="post" action="viewprofile.php">
	    
	   
	  
        <table width="348" border="1">
          <?php 
							 while($row=mysqli_fetch_array($sql))  
							 {
							?>
          <tr>
            <td>Name</td>
            <td><input name="name" type="text" value="<?php echo $row['name'];?>" id="name"></td>
          </tr>
          <tr>
            <td>Gender</td>
            <td><input type="radio" name="gender" value="male" checked>Male
            <input type="radio" name="gender" value="female">Female</td></tr>
          <tr>
            <td>Mobno</td>
            <td><input name="mobile" type="text" id="mobno" value="<?php echo $row['mobile'];?>"></td>
          </tr>
             <tr>
            <td>Pin</td>
            <td><input name="pin" type="text" id="pin" value="<?php echo $row['pin'];?>"></td>
          </tr>
             <tr>
            <td>Housename</td>
            <td><input name="house" type="text" id="hname" value="<?php echo $row['house'];?>"></td>
          </tr>
          
    
           
          
                    <tr>
            <td>Mail</td>
            <td><input name="mail" type="text" id="mail" value="<?php echo $row['mail'];?>"></td>
          </tr>
         <tr>
         <td>DOB</td>
            <td><input name="dob" type="date" id="dob" value="<?php echo $row['dob'];?>"></td>
          </tr>
		 
		 
		  
          <tr>
            <td colspan="2"><div align="center">
                <input type="submit" name="submit" value="submit" id="submit">
                
            </div></td>
            </tr>
            <?php
}
?>

        </table>
		

        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form>
      <p>&nbsp;</p>
    </div></td>
    <td width="579"></td>
  </tr>
  <tr>
    <td height="13"></td>
    <td></td>
    <td></td>
  </tr>
</table>

<?php
  


    if(isset($_POST['submit']))
    {
      $s1=$_POST['name'];
	  $s2=$_POST['gender'];
	  $s3=$_POST['mobile'];
	  $s4=$_POST['pin'];
	
	  $s6=$_POST['house'];
	  $s7=$_POST['mail'];
	  $s8=$_POST['dob'];
	  
       ?>
            <script>
             alert($s1);
             </script>
             <?php
  
         $sql="UPDATE homereg SET name='$s1',gender='$s2',mobile='$s3',pin='$s4',house='$s6',mail='$s7',dob='$s8' WHERE loginid ='$lid'";
    
      
      $ch=mysqli_query($co,$sql);
              
       if($ch)
          
          {?>
            <script>
             alert("Updated successfully");
             </script>
             <?php
          }
        else
          {
           
          }
      }
    
        mysqli_close($co);
  ?>


</body>
</html>

<?php
}
else
header("location:login.php");
?>