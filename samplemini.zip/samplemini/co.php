
<html>
<body>
<?php
$server = 'localhost';
$user = 'root' ;
$password = '' ;
$db = 'thanal';
$co = mysqli_connect($server, $user, $password, $db); 
if($co) {
echo "";
	//die("connection failed:" . $con->connect_error);
}
else
{
echo "database not created";
}
?>
</body>
</html>