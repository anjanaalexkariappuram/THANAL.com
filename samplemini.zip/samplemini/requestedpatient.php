 <?php 
include 'co.php'; 
?>
 
 <!DOCTYPE html>
<html>
	<head>

		
		
     
	
	</head>

	<body id="home">
		
  <table  border="0" width="100%">
    <center><h1><u>Requested Patients</u></h1></center></table>
			


	
		<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>		
<table border="1" cellpadding="10" width="20%" class="table table-striped" >
  <tr><th>Patient Name</th>
    <th>Homenurse Name</th>
    
	
	<th>Verify</th>
	<th>Reject</th>
    
  </tr>
<?php

$res=mysqli_query($co,"select * from homereg where apstatus='0' ");
while($row=mysqli_fetch_assoc($res))
{
	
	$lid=$row['loginid'] ;
	$sq=mysqli_query($co,"select username from login1 where loginid='$lid' ");
	$r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
	$em=$r['username'];
?>

<tr>
<td> 
   <?php 
        echo $row['name'];
    ?>
  </td>
  <td> 
   <?php 
        echo $row['gender'];
    ?>
  </td>
<td>
<?php
echo $row['mobile'];
?>
</td>
<td>
<?php
echo $row['pin'];
?>
</td>
<td>
<?php
echo $row['house'];
?>
</td>
<td>
<?php
echo $row['mail'];
?>
</td>
<td>
<?php
echo $row['dob'];
?>
</td>
<td>
<?php
echo $row['uploadcertificate'];
?>
</td>
<td>
<a href="adminapprove.php?id=<?php echo $lid; ?> ">Approved</a>
</td>
<td>
<a href="adminreject.php?id=<?php echo $lid; ?>">Reject</a>
</td>
</tr>
<?php
}
?>
</body>

</html>