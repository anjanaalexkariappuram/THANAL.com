
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" href="img/favicon.png" type="image/png">
  <title>Hospice Medical</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="vendors/linericon/style.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
  <link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
  <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
  <link rel="stylesheet" href="vendors/animate-css/animate.css">
  <link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
  <!-- main css -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
    
    
</head>

<body>



  <!--================Header Menu Area =================-->
  <header class="header_area">
    <div class="top_menu row m0">
      
        
      </div>
    </div>
    <div class="main_menu">
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <a class="navbar-brand logo_h" href="">
            <img src="newlogo.png" alt="">
                        
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
           aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- Collect the nav links, forms, and other content for toggling -->
          
      </nav>
    </div>
  </header>
  <br><br><br><br><br><br><br><br><br>
<?php
session_start();
$login=$_SESSION['login'];
$usr_name=$_SESSION['docname'];
$lid=$_SESSION['loginid'];
if($login)
{
	?>
<?php
include 'co.php';
$q="select * from district";
$sq=mysqli_query($co,$q);
$q1="select * from docterreg where loginid='$lid'";
$sql=mysqli_query($co,$q1);
?>


<table width="1536" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="291" height="363"></td>
    <td width="366" valign="top"><div align="center">
      <p>Edit your profile </p>
      
      <form name="form1" method="post" action="docviewprofile.php">
	    
	   
	  
        <table width="238" border="1">
          <?php 
							 while($row=mysqli_fetch_array($sql))  
							 {
							?>
          <tr>
            <td>Name</td>
            <td><input name="docname" type="text" value="<?php echo $row['docname'];?>" id="name"></td>
          </tr>
          <tr>
            <td>Mobno</td>
            <td><input name="docmob" type="text" id="mobno" value="<?php echo $row['docmob'];?>"></td>
          </tr>
             <tr>
            <td>City</td>
            <td><input name="doccity" type="text" id="city" value="<?php echo $row['doccity'];?>"></td>
          </tr>
             <tr>
            <td>Housename</td>
            <td><input name="dochouse" type="text" id="hname" value="<?php echo $row['dochouse'];?>"></td>
          </tr>
          
    
           
            <td>Gender</td>
            <td><input type="radio" name="gender" value="male" checked>Male
            <input type="radio" name="gender" value="female">Female</td></tr>
          </tr>
                    <tr>
            <td>Hospital Name</td>
            <td><input name="hospname" type="text" id="hospname" value="<?php echo $row['hospname'];?>"></td>
          </tr>
         <tr>
         <td>Specialization</td>
            <td><input name="specialization" type="text" id="specialization" value="<?php echo $row['specialization'];?>"></td>
          </tr>
		 
		 <tr>
         <td>Experience</td>
            <td><input name="experience" type="text" id="experience" value="<?php echo $row['experience'];?>"></td>
          </tr>
		  <tr>
            <td>Qualification</td>
            <td><input name="qualification" type="text" id="state" value="<?php echo $row['qualification'];?>"></td>
          </tr>
		  
          <tr>
            <td colspan="2"><div align="center">
                <input type="submit" name="submit" value="submit" id="submit">
                
            </div></td>
            </tr>
            <?php
}
?>

        </table>
		

        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form>
      <p>&nbsp;</p>
    </div></td>
    <td width="579"></td>
  </tr>
  <tr>
    <td height="13"></td>
    <td></td>
    <td></td>
  </tr>
</table>

<?php
  


    if(isset($_POST['submit']))
    {
      $s1=$_POST['docname'];
	  $s2=$_POST['docmob'];
	  $s3=$_POST['doccity'];
	  $s4=$_POST['dochouse'];
	
	  $s6=$_POST['gender'];
	  $s7=$_POST['hospname'];
	  $s8=$_POST['specialization'];
	  $s9=$_POST['experience'];
	  $s11=$_POST['qualification'];
       ?>
            <script>
             alert($s1);
             </script>
             <?php
  
         $sql="UPDATE docterreg SET docname='$s1',docmob='$s2',doccity='$s3',dochouse='$s4',docgender='$s6',hospname='$s7',specialization='$s8',experience='$s9',qualification='$s11' WHERE loginid ='$lid'";
    
      
      $ch=mysqli_query($co,$sql);
              
       if($ch)
          
          {?>
            <script>
             alert("Updated successfully");
             </script>
             <?php
          }
        else
          {
           
          }
      }
    
        mysqli_close($co);
  ?>


</body>
</html>

<?php
}
else
header("location:login.php");
?>