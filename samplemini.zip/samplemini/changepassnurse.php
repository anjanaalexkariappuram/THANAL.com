<?php
include'co.php';
session_start();
$uname= $_POST["username"];
//echo $email;

/*  if($user)
{

}
else{

}*/

if(isset($_POST['submit']))
  {

      $oldpass=$_POST['cupass'];
      $newpass=$_POST['newpass'];
      $confirmpass=$_POST['conpass'];


      //mysqli_select_db("oilmill");
      $p="select password from login1 where username='$uname'";
      $resultt=mysqli_query($co,$p);

      while ($row=mysqli_fetch_array($resultt)) {
        $pass=$row['password'];

        if($pass==$oldpass)
        {

            if ($newpass==$confirmpass)
             {
                $u="update login1 set password='$confirmpass' where username='$uname'";
                $update=mysqli_query($co,$u);

                if($update){?>
                    echo "<script>alert('Password successfully updated');
                    window.location='changepassnurse.html'</script>";
                    <?php

                }
                else{
                  ?>
                    echo "<script>alert('Error');
                    window.location='changepassnurse.html'</script>";
                    <?php
                }

            }
            else{
              ?>
                echo "<script>alert('Confirm password do not match');
                window.location='changepassnurse.html'</script>";
                <?php
            }
        }
            else{
              ?>
                  echo "<script>alert('Old password is incorrect');
                  window.location='changepassnurse.html'</script>";
                  <?php
            }
      }
    }
?>
