<?php 
session_start();
include 'co.php'; 
?>
<?php
if(isset($_POST["submit"]))
{


	$r=$_POST["uname"];

    $s=$_POST["pass"];
//    $_SESSION['r']=$r;
	
	$ins=mysqli_query($co,"select * from login1 where username='$r' and password='$s' ");
	 $m=mysqli_fetch_array($ins,MYSQLI_ASSOC);
	if($m>0)
	{
	
   
    $type=$m['usertype'];
   $lid=$m['loginid'];
   $sq=mysqli_query($co,"select apstatus from homereg where loginid='$lid'");
   $w=mysqli_fetch_array($sq,MYSQLI_ASSOC);
   
            $_SESSION['login']="1";
            $_SESSION['loginid']=$lid;
			
    if($type=='0')
    {    $_SESSION['type']="Admin";
        ?>
        <script type="text/javascript">window.location="homepage.php";</script>
        <?php

    }
   
    else if($type=='1' and $w['apstatus']=='1' )
    {
		$_SESSION['type']="Nurse";
				$sql1="select * from homereg where loginid ='$lid'";
				$result1=mysqli_query($co,$sql1);
				if($row1=mysqli_fetch_array($result1))
					$usr_name=$row1['name'];
				$_SESSION['nuname']=$usr_name;
		
    	?>
<script type="text/javascript">window.location="nursehome.php";</script>
        <?php


    }


    else if($type=='1' and $w['apstatus']=='0' )
    {

        
        ?>
<script type="text/javascript">alert("Approval Pending");window.location="login.php";</script>
        <?php


    }

	 else if($type=='2')
    {
		        $_SESSION['type']="Doctor";
				$sql1="select * from docterreg where loginid ='$lid'";
				$result1=mysqli_query($co,$sql1);
				if($row1=mysqli_fetch_array($result1))
					$usr_name=$row1['docname'];
				$_SESSION['docname']=$usr_name;
				$_SESSION['loginid']=$lid;
    	?>
<script type="text/javascript">window.location="doctorhome.php";</script>
        <?php


    }
 else if($type=='3')
    {
		 $_SESSION['type']="Patient";
				$sql1="select * from patientreg where loginid ='$lid'";
				$result1=mysqli_query($co,$sql1);
				if($row1=mysqli_fetch_array($result1))
					$usr_name=$row1['pname'];
				$_SESSION['pname']=$usr_name;
    	?>
<script type="text/javascript">window.location="patienthome.php";</script>
        <?php


    }
	else if($type=='4')
	{
	    $_SESSION['type']="Hospital";
        ?>
        <script type="text/javascript">window.location="hospitalhome.php";</script>
        <?php	
	}
     
    }
   else {
    		?>
    		<script type="text/javascript">
            alert("login failed");
            window.location='login.php'
            
        </script>  
    		<?php
    	}	
   }
   ?>


