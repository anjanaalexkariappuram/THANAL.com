<?php 
include 'co.php'; 
?>

<!DOCTYPE html>
<html>
<head>
	
       
       


       	<link rel="stylesheet" type="text/css" href="logincss.css">

 <title></title>
</head>
	<body>
		<div class="align-center">

		<h1 style="text-align:center;">LOGIN</h1>

		<form action="" method="POST">

        <table class="align-center">
       <tr>
       <td>
        		<input type="text" placeholder="UserName"  name=uname>	

        		</td>
        	   </tr>
       
       <tr>
       <td>
        		<input type="password" placeholder="Password" name=pass >	

        		</td>
              <tr>        	   </tr>
              <td>
               <input type="submit" value="submit" name="submit" >
                 
                </td>
                </tr>
<tr>
<td></td>
</tr>
             
        <tr>
        <td>
                 <a href="forgetpassword.html">&nbsp;&nbsp;Forgot Your Password?</a>
        </td>
        </tr>
<tr>
<td></td>
</tr>
        <tr>
        <td>
               New User? <a href="homepage.php">&nbsp;&nbsp;Register</a>
        </td>
        </tr>
      
        
        
        
         </table>
		 
		<?php 


include("co.php");
if(isset($_POST['submit']))
{
    $uname =$_POST['uname'];
	$pass =$_POST['pass'];


$sql="select * from login1 where username='$uname'";


$result=mysqli_query($co,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount!=0)
{

	while($row=mysqli_fetch_array($result))
	{
		$dbu_name=$row['username'];
		$dbu_pass=$row['password'];
		$dbu_type=$row['usertype'];

        
		if($dbu_name==$uname && $dbu_pass==$pass)
		{
			//$_SESSION['uname']=$dbu_name;
            //$_SESSION['pass']=$dbu_pass;
		     //echo $dbu_type;
			if($dbu_type==0)	
			{
				//$_SESSION['usertype']="admin";
               	header('Location: homepage.php');
			}
			else if($dbu_type==1)
			{
				//$_SESSION['usertype']="Seller";
                	header('Location: nursehome.php');
			}
			else if($dbu_type==2)
			{
				//$_SESSION['usertype']="User";
				header('Location: doctorhome.php');	
			}
		}
		else
        {
				//header("location:signin.php?error=wrong password");
          //echo "wrong";
        }
	}
}
else
{
			//header("location:signin.php?error=User Not Found");
			//echo "not found";	
}
}
?>




</form></div></body></html>










