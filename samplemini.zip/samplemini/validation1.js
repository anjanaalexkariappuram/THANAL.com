function validateform()
{
var x=document.forms["myform"]["docname"].value;
if(x=="")
{
alert("Please fill Name");
document.myform.docname.focus() ;
return false;
}
var a=document.forms["myform"]["docgender"].value;
if(a=="")
{
  alert("Please choose your Gender: Male or Female");
  document.myform.docgender.focus() ;
return false;
}
if( document.myform.docmobile.value == "" ||isNaN( document.myform.docmobile.value) ||document.myform.docmobile.value.length != 10 )
   {
     alert( "Please provide a 10 digit mobile no" );
     document.myform.docmobile.focus() ;
     return false;
   }
   var x=document.forms["myform"]["doccity"].value;
if(x=="")
{
alert("Please fill city");
document.myform.doccity.focus() ;
return false;
} 
var x=document.forms["myform"]["dochouse"].value;
if(x=="")
{
alert("Please fill housename");
document.myform.dochouse.focus() ;
return false;
} 
var x=document.forms["myform"]["hospname"].value;
if(x=="")
{
alert("Please fill Hospital Name");
document.myform.hospname.focus() ;
return false;
}

var x=document.forms["myform"]["specialization"].value;
if(x=="")
{
alert("Please fill Specialization");
document.myform.specialization.focus() ;
return false;
}
var x=document.forms["myform"]["experience"].value;
if(x=="")
{
alert("Please fill Experience");
document.myform.experience.focus() ;
return false;
}
var x=document.forms["myform"]["qualification"].value;
if(x=="")
{
alert("Please fill Qualification");
document.myform.qualification.focus() ;
return false;
}




/*var emailid = /^([a-z0-9A-Z_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,4})+$/;
var c=document.myform.mail.value;
 if(c==null || c=="")
	   {
	   alert("email can't be empty");
	   return false;
	   }
    if (!emailid.test(document.myform.mail.value)) {
    alert('Please provide a valid email id');
    emailid.focus;
    return false;
 }*/
   




if(myform.docusername.value == "") {
      alert("Error: Username cannot be blank!");
      document.myform.docusername.focus();
      return false;
    }
    

    if(myform.docusername.value.length < 6) {
        alert("Error: username must contain at least six characters!");
        document.myform.docusername.focus();
        return false;
      }
   

    if(myform.docpass.value != "" && myform.docpass.value == myform.doccpass.value) {
      if(myform.docpass.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        document.myform.docpass.focus();
        return false;
      }
      
      re = /[0-9]/;
      if(!re.test(myform.docpass.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        document.myform.docpass.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(myform.docpass.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        document.myform.docpass.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(myform.docpass.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        document.myform.docpass.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      document.myform.docpass.focus();
      return false;
    }

    return true;
 }