<?php
session_start();
$login=$_SESSION['login'];
$id=$_SESSION['loginid'];
$type=$_SESSION['type'];
$pn=$_GET['id'];
if($login)
{
    ?>
<?php
include 'co.php';
$q1="select * from appointment";
$sql=mysqli_query($co,$q1);
?>


<!doctype html>
<html lang="en">

<head>
<script type="text/javascript" src="validation1.js"></script>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="../../miniprojectn/thanaln/img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/bootstrap.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/linericon/style.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/font-awesome.min.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/animate-css/animate.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/style.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/responsive.css">
</head>

<body>



	<!--================Header Menu Area =================-->
	
    <br> <div class="col-lg-9">
                    <form class="row contact_form" name="myform" onsubmit="return validateform()" action="sendtime.php" method="POST" id="contactForm" novalidate>
                        <div class="col-md-6">
                            <div class="form-group"><br><br>
                            
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h3 class="pb-20 text-center mb-20">Send Appointment Time</h3>
                                <input name="pname" type="text" id="city" value="<?php echo $pn;?>"><br>
                              <br>  <input type="text" class="form-control" id="name" name="time" placeholder="Enter TIme Here" autocomplete="off">
                            </div>
                             <div class="col-md-12 text-right">
                            <button type="submit" value="submit" name="send" class="btn submit_btn">Send</button>
                             </div>
                        </div>
                        
                        
                       
                    </form>
                </div>
	
				
   </body>

</html>
<?php


if(isset($_POST['send']))
{
  $a=$_POST['time'];
  $b=$_POST['pname'];
  
 //$sq="insert into login1(username,password,usertype)values('$k','$l',2)";
//if(mysqli_query($co,$sq))
//{
	$s=mysqli_query($co,"select loginid from login1 where loginid='$id'");
	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
	$lid=$r['loginid'];
	/*echo "<script>alert('$lid');</script>";*/
$sql="insert into sendapptime (`loginid` , `time` , `patientname`) values ('$lid','$a','$b')";
$ch=mysqli_query($co,$sql);
if($ch)
{?>
	 <script>
 alert("Successfull");
</script>
	<?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($co);
}
}
}
//}
mysqli_close($co);
?>
    



