<?php
session_start();
if(!isset($_SESSION['sess']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html>
	<head>

		<title>HomeSter</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="adminhomecss.css">

		<!-- link for the Google API for Google Maps -->		
		<script src="https://maps.googleapis.com/maps/api/js"></script>
			
			

		<!-- link for the icon in the menu -->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
	
	</head>

	<body id="home">
		
	<!-- The Header with the menu -->
	
		

			<div class="menu">

				<div class="one container">

					<div class="logo pull-left">
						<h3><span class="weard">Home</span>Ster<span class="dot">.</span>com</h3>
					</div>

					<ul class="navigation pull-right">

						<li><a class="active" href="adminhome.php">Home</a></li>
						<li><a href="#"></a></li>
						<li><a href="viewlandlords.php">View Landlords </a></li>
						<li><a href="#"></a></li>
						<li><a href="viewcustomers.php">View Customers</a></li>
						<li><a href="#"></a></li>
						<li><a href="logout.php">logout</a></li>

					</ul>

				</div>

			</div>

<image src="pic8.jpg"width="1520px"height="850px">

		</div>


<!-- The Info in the Home page -->

		

<!-- The Footer -->

		

	</body>

</html>