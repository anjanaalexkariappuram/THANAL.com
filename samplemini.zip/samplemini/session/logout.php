<?php
session_start();
include "co.php";
session_unset();
header("location:index.php");
?>