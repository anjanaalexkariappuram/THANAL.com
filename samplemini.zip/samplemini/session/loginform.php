<?php 
session_start();
include 'co.php'; 
?>


<!DOCTYPE html>
<html>
<head>
<title>WEB PAGE</title>
<link rel="stylesheet" type="text/css" href="indexcss.css">
<style>
body{
      	background-image: url("pic2.jpg");
		width:"1503px";
		height:"850px";
		
      	    }
			 
        	.div1{
      
      	height:350px;
      	width:450px;
         background-color:white; 
         	border-radius:15px;
         	border: 2px solid #3399ff;
       	}

	#login
	{
		border:3px solid #3399ff;
		border-radius: 20px;
		color:#3399ff;
		height: 40px;
		width: 150px;
		background-color:white;
		margin-left:80px;
		margin-top: 10px;
			} 

     button:hover
      {
     	border:2px solid #3399ff;
     	color: white;
     	background-color: #3399ff;
     }  

       input[type="text"]
       {
       	height: 40px;
       	width: 300px;
       	border: 2px solid #3399ff;
       	margin-top: 10px;
       	padding-left: 10px;
       }
        	
      .align-center{
	  height:350px;
      	width:450px;
         background-color:white; 
         	border-radius:15px;
         	border: 2px solid #3399ff;
       	margin-left: auto;
       	margin-right: auto;
       }
	   .align-center1
	   {
	      margin-left: auto;
       	margin-right: auto;
	   }
	   
       input[type="text"]:hover{
       	border: 2px solid #e7e7e7;
       }
       

       input[type="password"]
       {
       	height: 40px;
       	width: 300px;
       	border: 2px solid #3399ff;
       	margin-top: 10px;
       	padding-left: 10px;
       }
	   
</style>


</head>


<body>
<div class="header">
<h1 ><font color="white">HOMESTER</h1><br> 
</div>
<div class="navbar">
<div class="dropdown">
 <button class="dropbtn">Registration
  </button> 
 <div class="dropdowncontent">
   <a href="Land-regform.php" color=blue>Landlords</a>
   <a href="Cus-regform.php" color=blue>Customer</a>
 </div>
</div>

<a href="index.php" color=blue>Home</a>
</div>
<br>
<br>
<br>
<div  class="align-center">

		<h1 style="text-align:center;">LOGIN</h1>

		<form action="" method="POST">

        <table class="align-center1">
       <tr>
       <td>
        		<input type="text" placeholder="UserName/Email"  name=uname>	

        		</td>
        	   </tr>
       
       <tr>
       <td>
        		<input type="password" placeholder="Password" name=pass >	

        		</td>
              <tr>        	   </tr>
              <td>
               <input type="submit" value="LOGIN" name="submit" >
                 
                </td>
                </tr>
<tr>
<td></td>
</tr>
             
        <tr>
        <td>
                 <a href="forgetpassword.html">Forgot Your Password?</a>
        </td>
        </tr>
<tr>
<td></td>
</tr>
        <tr>
        <td>
               New User? <a href="index.php">Register</a>
        </td>
        </tr>
      
        
        
        
         </table>
		 
		 <?php

if(isset($_POST['submit']))
{
	$con=mysqli_select_db($co,$db);

		
			
		$result = mysqli_query($co,"select * from login where `emailid`='$_POST[uname]' and `pasword`='$_POST[pass]' and `status`='valid' ");
		if($result)
		{
		$row=mysqli_fetch_array($result);
			if($_POST['uname']==$row['emailid']&&$_POST['pass']==$row['pasword'] && $row['usertype']=='2' && $row['status']=='valid')
			{
				$_SESSION['sess']=$row['emailid'];
			?>
			
				<script type="text/javascript">
					alert("Login Successfull!!!");
				</script>
				<script> location.href='land-homepage.php'</script>
		
		
	<?php
				
			
	}
	
     elseif($_POST['uname']==$row['emailid']&&$_POST['pass']==$row['pasword'] && $row['usertype']=='3' && $row['status']=='valid')
			{
				$_SESSION['sess']=$row['emailid'];
				?>
				<script type="text/javascript">
					alert("Login Successfull!!!");
				</script>
				<script> location.href='cus-homepage.php'</script>
				
				<?php
				
			
	}
	
	
		
	
     elseif($_POST['uname']==$row['emailid'] &&  $_POST['pass']==$row['pasword'] && $row['usertype']=='1' && $row['status']=='valid')
			{
				$_SESSION['sess']=$row['emailid'];
          					?>
				<script type="text/javascript">
					alert("Login Successfull!!!");
				</script>
				<script> location.href='adminhome.php'</script>
		<?php
		
	}
	else
	{
		?>
		<script type="text/javascript">
			alert("invalid username and password");
		</script>
	     <?php	
	}
}
}
?>


</form>


             </div>

</body>
</html>




