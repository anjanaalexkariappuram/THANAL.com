function validateform()
{
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please fill Name");
document.myform.name.focus() ;
return false;
}
var x=document.forms["myform"]["age"].value;
if(x=="")
{
alert("Please enter age");
document.myform.age.focus() ;
return false;
}
var a=document.forms["myform"]["pgender"].value;
if(a=="")
{
  alert("Please choose your Gender: Male or Female");
  document.myform.pgender.focus() ;
return false;
}

   var x=document.forms["myform"]["city"].value;
if(x=="")
{
alert("Please fill city");
document.myform.city.focus() ;
return false;
} 
var x=document.forms["myform"]["house"].value;
if(x=="")
{
alert("Please fill housename");
document.myform.house.focus() ;
return false;
} 
var x=document.forms["myform"]["category"].value;
if(x=="")
{
alert("Please fill Category");
document.myform.category.focus() ;
return false;
}









if(myform.username.value == "") {
      alert("Error: Username cannot be blank!");
      document.myform.username.focus();
      return false;
    }
    

    if(myform.username.value.length < 6) {
        alert("Error: username must contain at least six characters!");
        document.myform.username.focus();
        return false;
      }
   

    if(myform.pass.value != "" && myform.pass.value == myform.cpass.value) {
      if(myform.pass.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        document.myform.pass.focus();
        return false;
      }
      
      re = /[0-9]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        document.myform.pass.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        document.myform.pass.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        document.myform.pass.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      document.myform.pass.focus();
      return false;
    }

    return true;
 }