<?php 
include 'co.php'; 
?>


<!doctype html>
<html lang="en">

<head>
<script type="text/javascript" src="validation1.js"></script>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="../../miniprojectn/thanaln/img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/bootstrap.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/linericon/style.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/font-awesome.min.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/animate-css/animate.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/style.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/responsive.css">
</head>

<body>

<?php

$res=mysqli_query($co,"select * from docterreg ");
while($row=mysqli_fetch_assoc($res))
{
	
	$lid=$row['loginid'] ;
	$sq=mysqli_query($co,"select username from login1 where loginid='$lid' ");
	$r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
	$em=$r['username'];
?>


	<!--================Header Menu Area =================-->
	
    <div class="col-lg-9">
                    <form class="row contact_form" name="myform" onsubmit="return validateform()" action="" method="POST" id="contactForm" novalidate>
                        <div class="col-md-6">
                            <div class="form-group"><br>
                            
                            <h3 class="pb-20 text-center mb-20">Doctor Registration Form</h3>
                                <input type="text" class="form-control" id="name" name="docname" value="<?php echo $docname ;?>" autocomplete="off">
                            </div>
                             <div class="form-group">
                                <input type="text" class="form-control" id="mobile" name="docmobile" value="<?php echo $docmob ;?>" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="doccity" value="<?php echo $doccity ;?>" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="dochouse" value="<?php echo $dochouse ;?>" autocomplete="off">
                            </div>
                             <div class="form-select" id="service-select">
                           <select name="district" required autocomplete="off">
                                     <option value="district">District</option>
                                         <?php
                                           while($fetch=mysqli_fetch_array($db1))
						                       {
                                         ?>
                                    <option value="<?php echo $fetch['disid']?>"><?php echo $fetch['disname']?>  <?php
                                    }
						             ?>

                               </select>
          </div>
                            &nbsp&nbsp&nbsp&nbspGender:&nbsp&nbsp&nbsp
        		                <input type="radio" name="docgender" value="Male" checked>&nbsp&nbsp&nbsp&nbspMale&nbsp&nbsp <input type="radio" name="docgender"                                                 value="Female" >&nbsp&nbsp&nbsp&nbspFemale	
                             <div class="form-group">
                                <input type="text" class="form-control" id="" name="hospname" value="<?php echo $hospname ;?>" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="specialization" value="<?php echo $specialization ;?>" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="experience" value="<?php echo $experience ;?>" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="qualification" value="<?php echo $qualification ;?>" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="file" class="form-control" id="" name="doccertificate" placeholder="Upload Certificate Here"
                                 accept=".pdf,.jpg,.jpeg,.png" size="30">                             </div>
                            
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="docusername" placeholder="Username" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="" name="docpass"  placeholder="Password">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="" name="doccpass" placeholder="Confirm Password">
                            </div>
                             <div class="col-md-12 text-right">
                            <button type="submit" value="submit" name="submit" class="btn submit_btn">Submit</button>
                             </div>
                        </div>
                        
                        
                       
                    </form>
                </div>
	
				
   </body>

</html>

    



