

<?php
include "co.php";
$b=$_GET['id'];
$sq=mysqli_query($co,"update  homereg set apstatus='1' where loginid='$b'");

if ( $sq ){
echo "<script>alert('approved');
      window.location='approve.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>