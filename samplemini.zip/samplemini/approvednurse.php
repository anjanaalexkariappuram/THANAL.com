
<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
    
    <style>
     p {  text-align:justify;
		 
		 }
    </style>
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			
				
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="">
						<img src="newlogo.png" alt="">
                        
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					
			</nav>
		</div>
	</header>


 <?php 
include 'co.php'; 
?>
 
 


		
  <table  border="0" width="100%">
    <center><h1><u>Approved HomeNurse</u></h1></center></table>
			


	
		<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>		
<table border="1" cellpadding="10" width="20%" class="table table-striped" >
  <tr><th>Name</th>
    <th>Gender</th>
    <th>mobile</th>
	<th>pin</th>
    <th>housename</th>
    <th>mail</th>
    <th>dob</th>
	<th>certificate</th>
	
	
  </tr>
<?php

$res=mysqli_query($co,"select * from homereg where apstatus='1' ");
while($row=mysqli_fetch_assoc($res))
{
	
	$lid=$row['loginid'] ;
	$sq=mysqli_query($co,"select username from login1 where loginid='$lid' ");
	$r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
	$em=$r['username'];
?>

<tr>
<td> 
   <?php 
        echo $row['name'];
    ?>
  </td>
  <td> 
   <?php 
        echo $row['gender'];
    ?>
  </td>
<td>
<?php
echo $row['mobile'];
?>
</td>
<td>
<?php
echo $row['pin'];
?>
</td>
<td>
<?php
echo $row['house'];
?>
</td>
<td>
<?php
echo $row['mail'];
?>
</td>
<td>
<?php
echo $row['dob'];
?>
</td>
<td><a href="/drive/samplemini/certificates/<?php echo  $row['uploadcertificate'];?>"target="_blank">view certificate</a></td>


</tr>
<?php
}
?>
</body>

</html>