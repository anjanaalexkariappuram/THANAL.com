 
<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
    
    <style>
     p {  text-align:justify;
		 
		 }
    </style>
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			
				
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="">
						<img src="newlogo.png" alt="">
                        
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					
			</nav>
		</div>
	</header>



 <?php 
include 'co.php'; 
?>
 
 
		
  <table  border="0" width="60%">
    <center><h1><u>Approve or Reject Patient Request</u></h1></center></table>
			


	
		<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>	<br>		
<table border="1" cellpadding="10" width="10%" class="table table-striped" >
  <tr><th>Nurse Name</th>
    <th>Patient Name</th>
     <th>Start Date</th>
	  <th>End Date</th>
	<th>Verify</th>
	<th>Reject</th>
    
  </tr>
<?php

$res=mysqli_query($co,"select * from patientnursereq");
while($row=mysqli_fetch_assoc($res))
{
	
	$lid=$row['pnid'] ;
	$sq=mysqli_query($co,"select username from login1 where loginid='$lid' ");
	$r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
	$em=$r['username'];
?>

<tr>
<td> 
   <?php 
        echo $row['nnurse'];
    ?>
  </td>
  <td> 
   <?php 
        echo $row['patientname'];
    ?>
  </td>


	<td> 
   <?php 
        echo $row['startdate'];
    ?>
  </td>
  <td> 
   <?php 
        echo $row['enddate'];
    ?>
  </td>


<td>
<a href="?id=<?php echo $lid; ?> ">Approve</a>
</td>
<td>
<a href="?id=<?php echo $lid; ?>">Reject</a>
</td>
</tr>
<?php
}
?>
</body>

</html>