<?php 
include 'co.php'; 
$q1="select * from district";

 $db1=mysqli_query($co,$q1);
 

?>




<?php


if(isset($_POST['submit']))
{
  $a=$_POST['docname'];
  $b=$_POST['docmobile'];
  $c=$_POST['doccity'];
  $d=$_POST['dochouse'];
  $n=$_POST['district'];
  $e=$_POST['docgender'];
  $f=$_POST['hospname'];
  $g=$_POST['specialization'];
  $h=$_POST['experience'];
  $i=$_POST['qualification'];
  $j=$_POST['doccertificate'];
  $k=$_POST['docusername'];
  $l=$_POST['docpass'];
  $m=$_POST['doccpass'];
 
  
 $sq="insert into login1(username,password,usertype)values('$k','$l',2)";
if(mysqli_query($co,$sq))
{
	$s=mysqli_query($co,"select loginid from login1 where username='$k'");
	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
	$lid=$r['loginid'];
	//echo "<script>alert('$lid');</script>";
$sql="insert into doctorreg ( `docname` , `docmobile` , `doccity` , `dochouse` , `disid` , `docgender` , `hospname` , `specialization`, `experience`, `qualification` , `uploaddoccer`) values ( '$a', '$b', '$c', '$d', '$n', '$e', '$f', '$g', '$h', '$i', '$j' )";
$ch=mysqli_query($co,$sql);
if($ch)
{?>
	 <script>
 alert("Registration Successfull");
</script>
	<?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($co);
}
}
}
mysqli_close($co);
?>
    
