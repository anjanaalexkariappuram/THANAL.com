<?php 
include 'co.php'; 
$q1="select * from district";

 $db1=mysqli_query($co,$q1);
 

?>


<!doctype html>
<html lang="en">

<head>
<script type="text/javascript" src="validation1.js"></script>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="../../miniprojectn/thanaln/img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/bootstrap.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/linericon/style.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/font-awesome.min.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/animate-css/animate.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/style.css">
	<link rel="stylesheet" href="../../miniprojectn/thanaln/css/responsive.css">
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			
				
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="../../miniprojectn/thanaln/index.html">
						<img src="../../miniprojectn/thanaln/newlogo.png" alt="">
                        
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row ml-0 w-100">
							<div class="col-lg-12 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="../../miniprojectn/thanaln/index.html">Home</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="../../miniprojectn/thanaln/login.php">Login</a>
									</li>
									
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Registration</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="../../miniprojectn/thanaln/nursereg.php">Home Nurse</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="../../miniprojectn/thanaln/patientreg.html">Patient</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="../../miniprojectn/thanaln/docreg.html">Doctor</a>
											</li>
										</ul>
									</li>
									
									<li class="nav-item">
										<a class="nav-link" href="../../miniprojectn/thanaln/index.html">Logout</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->

	<!--================ Home Banner Area =================-->
	
	<!--================ End Home Banner Area =================-->

	<!--================ Procedure Category Area =================-->
    <br><br><br><br> <div class="col-lg-9">
                    <form class="row contact_form" name="myform" onsubmit="return validateform()" action="docreg.php" method="POST" id="contactForm" novalidate enctype="multipart/form-data">
                        <div class="col-md-6">
                            <div class="form-group"><br><br><br><br><br>
                            
                            <h3 class="pb-20 text-center mb-20">Doctor Registration Form</h3>
                                <input type="text" class="form-control" id="name" name="docname" placeholder="Full Name" autocomplete="off">
                            </div>
                             <div class="form-group">
                                <input type="text" class="form-control" id="mobile" name="docmobile" placeholder="Mobile Number" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="doccity" placeholder="City" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="dochouse" placeholder="House Name" autocomplete="off">
                            </div>
                             <div class="form-select" id="service-select">
                           <select name="district" required autocomplete="off">
                                     <option value="district">District</option>
                                         <?php
                                           while($fetch=mysqli_fetch_array($db1))
						                       {
                                         ?>
                                    <option value="<?php echo $fetch['disid']?>"><?php echo $fetch['disname']?>  <?php
                                    }
						             ?>

                               </select>
          </div>
                            &nbsp&nbsp&nbsp&nbspGender:&nbsp&nbsp&nbsp
        		                <input type="radio" name="docgender" value="Male" checked>&nbsp&nbsp&nbsp&nbspMale&nbsp&nbsp <input type="radio" name="docgender"                                                 value="Female" >&nbsp&nbsp&nbsp&nbspFemale	
                             <div class="form-group">
                                <input type="text" class="form-control" id="" name="hospname" placeholder="Hospital Name" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="specialization" placeholder="Specialization" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="experience" placeholder="Experience" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="qualification" placeholder="Qualification" autocomplete="off">
                            </div
                            ><div class="form-group">
                                <input type="file" class="form-control" id="doccertificate" name="doccertificate" >                             </div>
                            
                            <div class="form-group">
                                <input type="text" class="form-control" id="" name="docusername" placeholder="Username" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="" name="docpass"  placeholder="Password">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="" name="doccpass" placeholder="Confirm Password">
                            </div>
                             <div class="col-md-12 text-right">
                            <button type="submit" value="submit" name="submit" class="btn submit_btn">Submit</button>
                             </div>
                        </div>
                        
                        
                       
                    </form>
                </div>
	
				
   </body>

</html>
<?php


if(isset($_POST['submit']))
{
  $a=$_POST['docname'];
  $b=$_POST['docmobile'];
  $c=$_POST['doccity'];
  $d=$_POST['dochouse'];
  $n=$_POST['district'];
  $e=$_POST['docgender'];
  $f=$_POST['hospname'];
  $g=$_POST['specialization'];
  $h=$_POST['experience'];
  $i=$_POST['qualification'];

  $img=$_FILES["uploaddoccer"]["name"];
$target_dir = "certificates/";
$target_file = $target_dir . basename($_FILES["uploaddoccer"]["name"]);
move_uploaded_file($_FILES["uploaddoccer"]["tmp_name"], $target_file);
$image=$target_file;

  //$j=$_POST['doccertificate'];
  $k=$_POST['docusername'];
  $l=$_POST['docpass'];
  $m=$_POST['doccpass'];
 
  
 $sq="insert into login1(username,password,usertype)values('$k','$l',2)";
if(mysqli_query($co,$sq))
{
	$s=mysqli_query($co,"select loginid from login1 where username='$k'");
	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
	$lid=$r['loginid'];
	/*echo "<script>alert('$lid');</script>";*/
$sql="INSERT INTO `docterreg` (`docid`, `loginid`, `docname`, `docmob`, `doccity`, `dochouse`, `disid`, `docgender`, `username` `hospname`, `specialization`, `experience`, `qualification`, `uploaddoccer`) VALUES (NULL,'$lid', '$a', '$b', '$c', '$d', '$n', '$e', '$k', '$f', '$g', '$h', '$i', '$img')";
$ch=mysqli_query($co,$sql);
if($ch)
{?>
	 <script>
 alert("Registration Successfull");
</script>
	<?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($co);
}
}
}
mysqli_close($co);
?>
    



