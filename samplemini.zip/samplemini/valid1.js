function validateform()
{
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please fill Name");
document.myform.name.focus();
return false;
}
var a=document.forms["myform"]["gender"].value;
if(a=="")
{
  alert("Please choose your Gender: Male or Female");
  document.myform.gender.focus();
return false;
}
if( document.myform.mobile.value == "" ||isNaN( document.myform.mobile.value) ||document.myform.mobile.value.length != 10 )
   {
     alert( "Please provide a 10 digit mobile no" );
     document.myform.mobile.focus() ;
     return false;
   }
   
if( document.myform.pin.value == "" || isNaN( document.myform.pin.value) || document.myform.pin.value.length != 6)
   {
     alert( "Please provide a valid pincode" );
     document.myform.pin.focus() ;
     return false;
   }
var x=document.forms["myform"]["house"].value;
if(x=="")
{
alert("Please fill House Name");
document.myform.house.focus();
return false;
}






var emailid = /^([a-z0-9A-Z_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,4})+$/;
var c=document.myform.mail.value;
 if(c==null || c=="")
	   {
	   alert("email can't be empty");
	   return false;
	   }
    if (!emailid.test(document.myform.mail.value)) {
    alert('Please provide a valid email id');
    emailid.focus;
    return false;
 }
   
var a=document.forms["myform"]["dob"].value;
if(a=="")
{
alert("Please give date of birth");
return false;
}




if(myform.username.value == "") {
      alert("Error: Username cannot be blank!");
      myform.username.focus();
      return false;
    }
    

    if(myform.username.value.length < 6) {
        alert("Error: username must contain at least six characters!");
        myform.username.focus();
        return false;
      }
   

    if(myform.pass.value != "" && myform.pass.value == myform.cpass.value) {
      if(myform.pass.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        myform.pass.focus();
        return false;
      }
      
      re = /[0-9]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        myform.pass.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        myform.pass.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        myform.pass.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      myform.pass.focus();
      return false;
    }

    return true;
 }