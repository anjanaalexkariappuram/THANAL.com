<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
    
    <style>
     p {  text-align:justify;
		 
		 }
    </style>
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			
				
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="">
						<img src="newlogo.png" alt="">
                        
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					
			</nav>
		</div>
	</header>

<?php
session_start();
$login=$_SESSION['login'];
$id=$_SESSION['loginid'];
$type=$_SESSION['type'];
$nnurse=$_GET['id'];
if($login)
{
    ?>
<?php
include 'co.php';
$q1="select * from homereg where apstatus='1'";
$sql=mysqli_query($co,$q1);
?>






	<!--================Header Menu Area =================-->
	
    <br><br><br><br><br><br><br> <div class="col-lg-9">
                    <form class="row contact_form" name="myform" onsubmit="return validateform()" action="nurserequest.php" method="POST" id="contactForm" novalidate>
                        <div class="col-md-6">
                            <div class="form-group"><br><br>
                            
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h3 class="pb-20 text-center mb-20">Send Request</h3>
                                <input name="nnurse" type="text" id="city" value="<?php echo $nnurse;?>"><br>
                                <br>  <input type="text" class="form-control" id="name" name="patientname" placeholder="Enter Your Name Here" autocomplete="off"><br>
                               &nbsp; Select Start Date<br>  <input type="date" class="form-control" id="sdate" name="sdate" autocomplete="off"><br>
                              &nbsp;Select End Date  <br>  <input type="date" class="form-control" id="edate" name="edate"  autocomplete="off">

                            </div>
                             <div class="col-md-12 text-right">
                            <button type="submit" value="submit" name="send" class="btn submit_btn">Send</button>
                             </div>
                        </div>
                        
                        
                       
                    </form>
                </div>
	
				
   </body>

</html>
<?php


if(isset($_POST['send']))
{
  $a=$_POST['nnurse'];
  $b=$_POST['patientname'];
  $c=$_POST['sdate'];
  $d=$_POST['edate'];
  
 //$sq="insert into login1(username,password,usertype)values('$k','$l',2)";
//if(mysqli_query($co,$sq))
//{
	$s=mysqli_query($co,"select loginid from login1 where loginid='$id'");
	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
	$lid=$r['loginid'];
	/*echo "<script>alert('$lid');</script>";*/
$sql="insert into patientnursereq (`loginid` , `nnurse` , `patientname` , `startdate` , `enddate`) values ('$lid','$a','$b','$c','$d')";
$ch=mysqli_query($co,$sql);
if($ch)
{?>
	 <script>
 alert("Successfull");
</script>
	<?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($co);
}
}
}
//}
mysqli_close($co);
?>
    



