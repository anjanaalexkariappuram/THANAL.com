<?php 
include 'co.php'; 
?>




<?php


if(isset($_POST['submit']))
{
  $a=$_POST['name'];
  $b=$_POST['gender'];
  $c=$_POST['mobile'];
  $d=$_POST['pin'];
  $e=$_POST['house'];
  $f=$_POST['mail'];
  $g=$_POST['dob'];
  //$h=$_POST['uploadcertificate'];

   $img=$_FILES["uploadcertificate"]["name"];
$target_dir = "certificates/";
$target_file = $target_dir . basename($_FILES["uploadcertificate"]["name"]);
move_uploaded_file($_FILES["uploadcertificate"]["tmp_name"], $target_file);
$image=$target_file;

  
  $j=$_POST['username'];
  $k=$_POST['pass'];
  $l=$_POST['cpass'];
 
  
     $ss=mysqli_query($co,"select * from login1 where username='$j'");
	$i=mysqli_num_rows($ss);
	if($i>0)
	{
        echo "
        <script>
        alert('already exists username');
        </script>";


	}
	else
	{
		
 $sq="insert into login1(username,password,usertype)values('$j','$k',1)";
if(mysqli_query($co,$sq))
{
	
	$sql=mysqli_query($co,"select loginid from login1 where username='$j' ");
	$re=mysqli_fetch_array($sql,MYSQLI_ASSOC);
	$lid=$re['loginid'];
	
$sql="insert into homereg (`loginid`, `name` , `gender` , `mobile` , `pin` , `house` , `mail` , `dob`, `uploadcertificate` ,`apstatus` ) values ('$lid', '$a', '$b', '$c', '$d', '$e', '$f', '$g', '$img','0' )";
if(mysqli_query($co,$sql))
      echo "<script> alert('Success');
           window.location='login.php'</script>";
}
}
   }
?>