<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
    
    
    <style>
	p{   text-align:justify;
		
		}
    </style>
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			
				
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="">
						<img src="newlogo.png" alt="">
                        
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->

	
     <br><br>
      <section class="about_myself pad_bottom">
		<div class="container">
			
           <br><br><br><br><br><br><br><br><br> <h1>Mary Queens Hospital</h1>
			<p><span style="text-align:center;">The 10,000 sq.ft. rehabilitation area offers wide range of services, which include Physio Therapy, a well-equipped Neuro Rehabilitation Departement (Pediatrics and Adult), specially designed Clubs for Shoulder, Hand, Knee and Spine, the Shapewell (Obesity and Fitness) Club, Physiotherapy in Women’s Health, for pregnancy/ child birth and pelvic floor dysfunction, in addition to Incontinence Exercise guidelines and Therapy, and a Custom Splinting Workshop.It is one of the first Physiotherapy Dept established in Pune, providing systematic, organized and professional rehabilitation services. It is handled by a team of highly qualified Physiotherapists.Our department provides the necessary training to meet the total range of patient care responsibilities involved in preventing disabilities and promoting restoration of function to the physically impaired, including Musculoskeletal, Neuromuscular disorders that interfere with the physical function. Our management includes prescription of Exercise Therapy with the aid of continuous Passive movement device, Electronic Cervical and Lumbar Traction Unit, Moist Heat Therapy and Paraffin Wax Bath, Manual Therapy, Electrotherapy treatment – Short Wave Diathermy, Interferential Therapy, Infrared Radiation Therapy, Transcutaneous Electrical Nerve stimulation Therapy and Laser Probe.</span>
</p></br>
			<h2>Types of Our Physiotherapy</h2>	</br>
            <br><h3>Musculoskeletal physiotherapy</h3>	</br>
            <p>Otherwise known as orthopaedic physiotherapy, treatments that fall under this category focus on restoring function to the musculoskeletal system, including all muscles, joints, tendons, ligaments and bones.

Your physiotherapist will assess if these skeletal components are all working well together to ensure your body is moving at its optimum. Many injuries are as a result of the musculoskeletal system not working well as a whole.

Chronic pain, especially lower back pain  are also caused by the musculoskeletal system being out of alignment in different areas. Our musculoskeletal treatments focus on:
</p><br>

<h6> >>>&nbsp; &nbsp;&nbsp;reducing pain</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;increasing mobilisation</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;treating soft tissue damage</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;correcting skeletal alignment</h6><br>

             <img src="physio1.jpg" width="20%" height="100%"><br>

            <br><h3>Conventional Physiotherapy (Physical Therapy)</h3><br>		
			<p>This type of traditional therapy involves a lot of hands-on therapy, exercises, and stretching maneuvers to facilitate movement. The goal is to help a patient manage pain, improve circulation, prevent or reduce muscle atrophy, contractures, and weakness, and improve their overall health and wellness. This is done by helping to retrain your brain and body in an attempt to regain some or all lost mobility.

There are many different types of physiotherapy treatment techniques, including:
</p><br>

<h6> >>>&nbsp; &nbsp;&nbsp;Muscle stretching</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;Massage therapy</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;Joint manipulation</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;Acupuncture, and</h6><br>
<h6> >>>&nbsp; &nbsp;&nbsp;Neurodynamic exercises.</h6><br>
			<p>Spinal cord injury physiotherapy treatments are available at hospitals and rehabilitation centers throughout the United States. Furthermore, some treatments can be combined with PT to result in greater recovery results. For example, a study in the United Kingdom that used olfactory ensheathing cells (OECs) from nasal cavity skin cells to patch a man’s spinal cord injury that was sustained during a knife attack. When combined with hours of daily physiotherapy, the treatment led to increased muscle growth and helped him learn to walk again, as well as regain some bladder, bowel, and sexual functionality.</p><br>

					<img src="physio2.jpg" height="100%" width="20%"><br>	
					
				<br><h2>Activity-Based Therapy</h2><br>		
			<p>Activity-based therapy (ABT), or what is also known as activity-based restorative therapy (ABRT), is a form of therapeutic activity that assists in the rehabilitation and recovery of individuals with neurological conditions, spinal cord injuries, and other traumatic injuries. It involves a lot of repetitive muscle movements to promote neuroplasticity, strength training, and gait training.

Unlike conventional physical therapy, ABT requires you to physically be in a standing position and not seated in your wheelchair or lying down. This method of treatment allows you to enjoy the benefits of standing and avoid the health issues that result from sitting for prolonged periods, including (but not limited to):</p><br>

<h6> >>>&nbsp; &nbsp;&nbsp;Muscle spasms;</h6><br>
<h6> >>>Respiratory issues;</h6><br>
<h6> >>>Skin ulcers (pressure sores);</h6><br>
<h6> >>>Osteoporosis;</h6><br>
<h6> >>>Bowel function issues; and</h6><br>
<h6> >>>Urinary tract infections (UTIs).</h6><br>
<p>ABT centers are located throughout the United States and provide a wide variety of different services.</p>
               <img src="physio3.jpg" height="100%" width="20%"><br>

	<br><h2>Functional Electrical Stimulation</h2><br>		
			<p>Functional electrical stimulation (FES) is a form of treatment that applies brief electrical pulses to paralyzed or weakened muscles via electrodes to help improve or restore their function. Although largely underutilized, this form of treatment is being used to by some providers to assist with exercises that help to boost heart and lung function, as well as improve bladder and bowel function, and increase mobility.</p><br>
			<img src="physio4.jpg" height="100%" width="20%"><br>
		</div>
	</section>
	
	<!--================ start footer Area =================-->
			
				
</body>

</html>