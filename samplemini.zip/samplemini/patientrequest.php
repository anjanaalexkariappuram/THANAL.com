/*<?php
include "co.php";
$b=$_GET['id'];
$sq=mysqli_query($co,"update  homereg set apstatus='2' where loginid='$b'");

if ( $sq ){
echo "<script>alert('Request Sent');
      window.location='patientapprovenurse.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>*/